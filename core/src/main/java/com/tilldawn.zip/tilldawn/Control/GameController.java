package com.tilldawn.Control;

import java.security.Key;

import com.badlogic.gdx.Input.Keys;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.tilldawn.Model.App;
import com.tilldawn.Model.Game;

public class GameController {

    private PlayerController playerController;
    private WorldController worldController;
    private WeaponController weaponController;

    private Game game;

    public GameController(Game game, PlayerController playerController, WorldController worldController,
            WeaponController weaponController) {
        this.game = game;
        this.playerController = playerController;
        this.worldController = worldController;
        this.weaponController = weaponController;
    }

    public void updateGame(Stage stage) {
        worldController.update();
        playerController.update();
        weaponController.update();
        updateLabels(stage);
    }

    public void updateLabels(Stage stage) {
        stage.clear();
        Label timeLabel = new Label(
                String.format("Time: %02d:%02d", getGame().getRemainingTime() / 60,
                        getGame().getRemainingTime() % 60),
                App.getSkin());
        Label killsLabel = new Label("Kills: " + getGame().getKills(), App.getSkin());
        Label ammoLabel = new Label("Ammo: " + getWeaponController().getWeapon().getAmmo() + "/"
                + getWeaponController().getWeapon().getType().getMaxAmmo(), App.getSkin());
        Label HPLabel = new Label("HP: " + getPlayerController().getPlayer().getHealth(), App.getSkin());
        Label levelLabel = new Label("Level: " + getPlayerController().getPlayer().getLevel(),
                App.getSkin());

        Table table = new Table();

        table.top();
        table.setFillParent(true);
        table.add(timeLabel).expandX().padTop(10);
        table.add(killsLabel).expandX().padTop(10);
        table.add(ammoLabel).expandX().padTop(10);
        table.add(HPLabel).expandX().padTop(10);
        table.add(levelLabel).expandX().padTop(10);

        stage.addActor(table);
    }

    private int getDeltaX(int i) {
        int deltaX = 1;
        if (i == Keys.A)
            deltaX = -1;
        else if (i == Keys.D)
            deltaX = 1;

        return deltaX * playerController.getPlayer().getSpeed() * 10;
    }

    private int getDeltaY(int i) {
        int deltaY = 1;
        if (i == Keys.W)
            deltaY = -1;
        else if (i == Keys.S)
            deltaY = 1;

        return deltaY * playerController.getPlayer().getSpeed() * 10;
    }

    public void handlePlayerMovement(int i) {
//        playerController.handlePlayerMovement();

        playerController.handlePlayerRun(i);
        // int deltaX = getDeltaX(i);
        // int deltaY = getDeltaY(i);

        // weaponController.moveAllBullets(deltaX, deltaY);
    }

    public void handlePlayerIdle(int i) {
        playerController.handlePlayerIdle();
    }

    public PlayerController getPlayerController() {
        return playerController;
    }

    public WorldController getWorldController() {
        return worldController;
    }

    public WeaponController getWeaponController() {
        return weaponController;
    }

    public Game getGame() {
        return game;
    }
}
