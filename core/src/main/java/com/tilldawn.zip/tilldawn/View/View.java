package com.tilldawn.View;

import com.badlogic.gdx.Screen;

public abstract class View implements Screen {
    
}
