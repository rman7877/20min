package com.tilldawn.Model.Enemies;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.tilldawn.Model.CollisionRect;
import com.tilldawn.Model.GameAssetManager;

public class Tree extends Enemy {


    public Tree(Sprite sprite, Animation<Sprite> animation, CollisionRect rect) {
        super(sprite, animation, rect);
    }

    @Override
    public void update() {
            
    }





}
